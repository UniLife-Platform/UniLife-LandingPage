(function(){
  var reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  var pointerFine = window.matchMedia('(pointer: fine)').matches;

  /* ---------- scroll progress bar ---------- */
  var bar = document.querySelector('.scroll-progress');
  function updateProgress(){
    if(!bar) return;
    var h = document.documentElement;
    var scrolled = (h.scrollTop) / (h.scrollHeight - h.clientHeight) * 100;
    bar.style.width = (isFinite(scrolled) ? scrolled : 0) + '%';
  }
  document.addEventListener('scroll', updateProgress, {passive:true});
  updateProgress();

  /* ---------- mobile menu ---------- */
  var hamburger = document.querySelector('.hamburger');
  var mobileMenu = document.querySelector('.mobile-menu');
  if(hamburger && mobileMenu){
    function closeMenu(){
      hamburger.classList.remove('open');
      mobileMenu.classList.remove('open');
      document.body.style.overflow = '';
    }
    function openMenu(){
      hamburger.classList.add('open');
      mobileMenu.classList.add('open');
      document.body.style.overflow = 'hidden';
    }
    hamburger.addEventListener('click', function(){
      if(mobileMenu.classList.contains('open')) closeMenu(); else openMenu();
    });
    mobileMenu.querySelectorAll('a').forEach(function(a){
      a.addEventListener('click', closeMenu);
    });
    document.addEventListener('keydown', function(e){
      if(e.key === 'Escape') closeMenu();
    });
  }

  /* ---------- scroll reveal ---------- */
  var revealEls = document.querySelectorAll('[data-reveal]');
  if(revealEls.length){
    revealEls.forEach(function(el, i){
      if(!el.style.transitionDelay){
        var group = el.closest('[data-reveal-group]');
        if(group){
          var siblings = Array.prototype.slice.call(group.querySelectorAll('[data-reveal]'));
          var idx = siblings.indexOf(el);
          el.style.transitionDelay = (idx * 0.08) + 's';
        }
      }
    });
    if(reduced){
      revealEls.forEach(function(el){ el.classList.add('revealed'); });
    } else {
      var io = new IntersectionObserver(function(entries){
        entries.forEach(function(entry){
          if(entry.isIntersecting){
            entry.target.classList.add('revealed');
            io.unobserve(entry.target);
          }
        });
      }, {threshold:0.15, rootMargin:'0px 0px -40px 0px'});
      revealEls.forEach(function(el){ io.observe(el); });
    }
  }

  /* ---------- split-text hero reveal ---------- */
  document.querySelectorAll('[data-split]').forEach(function(el){
    var text = el.textContent.trim();
    var words = text.split(/\s+/);
    el.innerHTML = '';
    words.forEach(function(word, i){
      var mask = document.createElement('span');
      mask.className = 'word-mask';
      var span = document.createElement('span');
      span.className = 'word';
      span.textContent = word;
      span.style.animationDelay = (0.15 + i * 0.06) + 's';
      mask.appendChild(span);
      el.appendChild(mask);
      el.appendChild(document.createTextNode(' '));
    });
  });

  /* ---------- magnetic buttons (desktop only) ---------- */
  if(pointerFine && !reduced){
    document.querySelectorAll('.magnetic').forEach(function(btn){
      btn.addEventListener('mousemove', function(e){
        var r = btn.getBoundingClientRect();
        var x = e.clientX - r.left - r.width/2;
        var y = e.clientY - r.top - r.height/2;
        btn.style.transform = 'translate(' + (x*0.18) + 'px,' + (y*0.35) + 'px)';
      });
      btn.addEventListener('mouseleave', function(){
        btn.style.transform = 'translate(0,0)';
      });
    });

    /* ---------- tilt cards ---------- */
    document.querySelectorAll('.tilt').forEach(function(card){
      card.addEventListener('mousemove', function(e){
        var r = card.getBoundingClientRect();
        var x = (e.clientX - r.left) / r.width - 0.5;
        var y = (e.clientY - r.top) / r.height - 0.5;
        card.style.transform = 'perspective(700px) rotateY(' + (x*8) + 'deg) rotateX(' + (y*-8) + 'deg) translateY(-4px)';
      });
      card.addEventListener('mouseleave', function(){
        card.style.transform = 'perspective(700px) rotateY(0) rotateX(0) translateY(0)';
      });
    });
  }
})();